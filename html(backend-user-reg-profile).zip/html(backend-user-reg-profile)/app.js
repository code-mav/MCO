// app.js
const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const methodOverride = require('method-override');
const session = require('express-session');

const userRoutes = require('./routes/userRoutes');  // (Optional) API endpoints
const pageRoutes = require('./routes/pageRoutes');  // Page routes (EJS)

const app = express();

// Middleware for parsing JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Use method-override to support PUT and DELETE from forms
app.use(methodOverride('_method'));

// Serve static files from the public folder
app.use(express.static(path.join(__dirname, 'public')));

// Set EJS as the templating engine and specify the views folder
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Configure express-session
app.use(
  session({
    secret: 'someSuperSecretKey', // Replace with a secure, random key in production
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 } // 1 hour session (example)
  })
);

// Connect to MongoDB (remove deprecated options if you like)
mongoose
  .connect('mongodb+srv://hana:mco2group4s21@cluster0.gtzef.mongodb.net/test?retryWrites=true&w=majority')
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Mount routes
app.use('/api/users', userRoutes); // Optional: CRUD or other API endpoints
app.use('/', pageRoutes);          // Page routes for EJS rendering

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
